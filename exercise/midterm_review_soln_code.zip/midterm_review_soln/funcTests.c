#include <stdlib.h>
#include <string.h>
#include "tctest.h"

/*
 * Prototypes for assembly functions
 */
long strLen(const char *s);
void makePositive(long *a, long n);
void printSum(long a, long b);
long mult1(void);
long mult2(void);

/*
 * Test fixture data type
 */
typedef struct {
	/* no fields are needed */
} TestObjs;

/*
 * Test fixture setup/cleanup functions: these
 * are called automatically as part of executing each
 * test function.
 */
TestObjs *setup(void);
void cleanup(TestObjs *objs);

/* test functions */
void testStrLen(TestObjs *objs);
void testMakePositive(TestObjs *objs);
void testPrintSum(TestObjs *objs);
void testMultFuncs(TestObjs *objs);

int main(void) {
	TEST_INIT();

	TEST(testStrLen);
	TEST(testMakePositive);
	TEST(testPrintSum);
	TEST(testMultFuncs);

	TEST_FINI();
}

TestObjs *setup(void) {
	TestObjs *objs = malloc(sizeof(TestObjs));
	/* no test data is needed */
	return objs;
}

void cleanup(TestObjs *objs) {
	free(objs);
}

void testStrLen(TestObjs *objs) {
	ASSERT(0L == strLen(""));
	ASSERT(5L == strLen("hello"));
	ASSERT(12L == strLen("hello, world"));
	ASSERT(24L == strLen("Assembly language is fun"));
}

void testMakePositive(TestObjs *objs) {
	long myArr[] = { 4, -9, 9, 7, -1 };

	makePositive(myArr, 5);

	ASSERT(4L == myArr[0]);
	ASSERT(9L == myArr[1]);
	ASSERT(9L == myArr[2]);
	ASSERT(7L == myArr[3]);
	ASSERT(1L == myArr[4]);
}

void testPrintSum(TestObjs *objs) {
	printSum(4, 5);
}

void testMultFuncs(TestObjs *objs) {
	ASSERT(720L == mult1());
	ASSERT(720L == mult2());
}
