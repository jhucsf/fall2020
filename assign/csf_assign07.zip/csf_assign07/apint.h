/*
 * Arbitrary-precision integer data type
 */

#ifndef APINT_H
#define APINT_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  /* TODO: add fields */
} ApInt;

/* Constructors and destructors */
ApInt *apint_create_from_u64(uint64_t val);
ApInt *apint_create_from_hex(const char *hex);
ApInt *apint_duplicate(const ApInt *ap);
void apint_destroy(ApInt *ap);

/* Operations */
uint64_t apint_get_bits(const ApInt *ap, unsigned n);
int apint_highest_bit_set(const ApInt *ap);
ApInt *apint_lshift(const ApInt *ap);
ApInt *apint_lshift_n(const ApInt *ap, unsigned n);
char *apint_format_as_hex(const ApInt *ap);
ApInt *apint_add(const ApInt *a, const ApInt *b);
ApInt *apint_sub(const ApInt *a, const ApInt *b);
int apint_compare(const ApInt *left, const ApInt *right);

/* Additional functions for Assignment 7 */
int apint_is_bit_set(const ApInt *ap, unsigned n);
ApInt *apint_mul(const ApInt *a, const ApInt *b);

#ifdef __cplusplus
}
#endif

#endif /* APINT_H */
