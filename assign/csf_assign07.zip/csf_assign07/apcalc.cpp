#include <cassert>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include "apint.h"

int main() {
  std::string line;

  while (std::getline(std::cin, line)) {
    // TODO: tokenize the line, evaluate the expression, etc.
  }
  std::cout << "done" << std::endl;

  return 0;
}
