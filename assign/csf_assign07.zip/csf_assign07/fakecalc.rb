#! /usr/bin/env ruby

# This Ruby program is a fairly close approximation of the apcalc program,
# implemented by delegating expression evaluation to the bc program.
# You can use this program to generate known-good calculation results
# to compare your apcalc program against.

require 'open3'

varmap = {}

STDIN.each_line do |line|
  line.rstrip!

  tokens = line.split(/\s+/)

  var = nil
  if tokens.length > 2 && tokens[1] == '='
    var = tokens[0]
    tokens.shift
    tokens.shift
  end

  expr = []
  missing_var = false

  tokens.each do |tok|
    if tok.start_with?('0x')
      # strip off the 0x prefix: also,
      # bc requires hexadecimal numbers to be in upper case
      tok = tok[2..-1].upcase
    elsif /^[a-zA-Z]+/.match(tok)
      # variable reference, replace with value
      if !varmap.has_key?(tok)
        missing_var = true
      else
        #puts "Substituting #{tok} with #{varmap[tok]}"
        tok = varmap[tok]
      end
    end
    expr.push(tok)
  end

  if missing_var
    puts "Invalid"
  else
    line = expr.join(' ')

    stdout_str, stderr_str, status = Open3.capture3('sh', '-c', "(echo 'obase=16'; echo 'ibase=16'; echo '#{line}') | bc")
    if !status.success?
      puts "Failed?"
    else
      stdout_str.rstrip!
      if stdout_str != ''
        result = "0x#{stdout_str.downcase}"
        puts result
        if !var.nil?
          #puts "Setting #{var} to #{stdout_str}"
          varmap[var] = stdout_str
        end
      end
    end
  end
end
